# AIUB Lost & Found

A full PHP + MySQL web application that lets AIUB students and staff report lost or found
items. The system automatically compares new reports against existing ones (category,
keywords, color, brand, location, date) and, when a strong match is found, notifies the
owner of the lost item by **email** and an **in-app notification**.

## Features

- User registration & login (secure password hashing)
- Report a lost item (with optional photo)
- Report a found item (with optional photo)
- Automatic matching engine — scores similarity 0-100% and creates a match when it
  crosses the threshold (default 55%, configurable in `config/database.php`)
- Email + in-app notification the moment a match is found
- Browse & search/filter lost and found listings by keyword or category
- Personal dashboard: track your own reports, mark items as resolved
- Fully responsive, professional UI (Bootstrap 5)

## Requirements

- PHP 8.0+ with PDO MySQL extension
- MySQL 5.7+ / MariaDB
- A local server stack: XAMPP, WAMP, Laragon, or any LAMP/LEMP hosting

## Setup

1. **Copy the project** into your server's web root, e.g. `htdocs/aiub-lost-and-found`.
2. **Create the database**: open phpMyAdmin (or the MySQL CLI) and import `database.sql`.
   This creates the `aiub_lost_found` database and all required tables.
3. **Configure the connection**: open `config/database.php` and set:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'aiub_lost_found');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   define('SITE_URL', 'http://localhost/aiub-lost-and-found'); // no trailing slash
   ```
4. **Make the uploads folder writable**:
   ```bash
   chmod -R 755 uploads/
   ```
5. **Visit the site** in your browser, e.g. `http://localhost/aiub-lost-and-found/index.php`.
6. **Register an account** and start posting lost/found reports.

## Enabling real email delivery (production)

By default, `includes/functions.php` → `send_email_notification()` uses PHP's built-in
`mail()` function, which requires a configured mail server (works automatically on most
shared hosting, e.g. cPanel). For Gmail/SMTP-based delivery (recommended for reliability),
install PHPMailer via Composer:

```bash
composer require phpmailer/phpmailer
```

Then replace the body of `send_email_notification()` with a PHPMailer SMTP block using
your Gmail App Password or your university's SMTP relay. The function signature
(`$toEmail, $toName, $subject, $htmlBody`) does not need to change, so no other file
needs editing.

## Tuning the matching algorithm

Open `includes/matching.php` — `calculate_match_score()` — to adjust the weighting given
to category, keyword overlap, color, brand, location, and date proximity. The minimum
score required to trigger a match/notification is set by `MATCH_THRESHOLD` in
`config/database.php`.

## Project Structure

```
aiub-lost-and-found/
├── auth/                  Login, register, logout
├── config/database.php    DB connection + site settings
├── includes/              Shared header/footer, helper functions, matching engine
├── assets/css/style.css   Site-wide styling
├── assets/js/script.js    Image preview + form validation
├── uploads/lost/          Uploaded lost-item photos
├── uploads/found/         Uploaded found-item photos
├── database.sql           Import this to create the DB
├── index.php               Homepage
├── report-lost.php         Report lost item form
├── report-found.php        Report found item form
├── browse-lost.php         Browse/search lost items
├── browse-found.php        Browse/search found items
├── item-details.php        Single item view + matches + contact info
├── dashboard.php           User's own reports
└── notifications.php       Full notification list
```
